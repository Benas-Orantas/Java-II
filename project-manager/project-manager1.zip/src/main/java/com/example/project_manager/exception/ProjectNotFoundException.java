package com.example.project_manager.exception;

public class ProjectNotFoundException extends RuntimeException{
        ProjectNotFoundException() {
            super("Project not found");
        }
}
