package com.example.project_manager.exception.handler;

public class ErrorResponse {
}
